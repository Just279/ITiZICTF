import networkx as nx
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import subprocess
import tkinter as tk
from tkinter import ttk, messagebox

class NetworkScannerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Сетевой сканнер")

        self.ip_label = ttk.Label(root, text="IP-адрес сети:")
        self.ip_entry = ttk.Entry(root)

        self.login_label = ttk.Label(root, text="Логин SSH:")
        self.login_entry = ttk.Entry(root)

        self.password_label = ttk.Label(root, text="Пароль SSH:")
        self.password_entry = ttk.Entry(root, show="*")

        self.scan_button = ttk.Button(root, text="Сканировать", command=self.scan_network)

        self.ip_label.grid(row=0, column=0, padx=10, pady=5, sticky=tk.W)
        self.ip_entry.grid(row=0, column=1, padx=10, pady=5)
        self.login_label.grid(row=1, column=0, padx=10, pady=5, sticky=tk.W)
        self.login_entry.grid(row=1, column=1, padx=10, pady=5)
        self.password_label.grid(row=2, column=0, padx=10, pady=5, sticky=tk.W)
        self.password_entry.grid(row=2, column=1, padx=10, pady=5)
        self.scan_button.grid(row=3, column=0, columnspan=2, pady=10)

    def scan_network(self):
        ip_address = self.ip_entry.get()
        ssh_username = self.login_entry.get()
        ssh_password = self.password_entry.get()

        if not ip_address or not ssh_username or not ssh_password:
            messagebox.showerror("Ошибка", "Введите данные для доступа по SSH")
            return

        # Замените эту строку на ваш путь к скрипту
        script_path = "/home/exhausted/Рабочий\ стол/scriptLVS.sh"

        cmd = f'{script_path} "{ip_address}" "{ssh_username}" "{ssh_password}"'
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)

        if result.returncode == 0:
            messagebox.showinfo("Успех", "Сканирование завершено успешно!")
            system_info = result.stdout
            self.show_network_graph(ip_address, system_info)
        else:
            messagebox.showerror("Ошибка", f"Ошибка при сканировании: {result.stderr}")

   
    def show_network_graph(self, ip_address, system_info):
        self.graph_window = tk.Toplevel(self.root)
        self.graph_window.title("Схема локальной сети")

        figure = Figure(figsize=(5, 4), dpi=100)
        plot = figure.add_subplot(1, 1, 1)

        # Замените эту строку на ваш код построения графа
        network_graph = {'Node1': ['Node2', 'Node3'], 'Node2': ['Node4'], 'Node3': [], 'Node4': []}

        self.draw_network_graph(network_graph, plot)

        canvas = FigureCanvasTkAgg(figure, master=self.graph_window)
        canvas.draw()
        canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=1)

        # Добавляем информацию при наведении на узлы
        def on_hover(event):
            node, = plot.pick(event.x, event.y)
            if node:
                node_info = f"Информация о узле {node.get_label()}:\n\n{system_info}"
                messagebox.showinfo("Подробная информация", node_info)

        canvas.mpl_connect("motion_notify_event", on_hover)

    def draw_network_graph(self, graph, plot):
        G = nx.Graph(graph)
        pos = nx.spring_layout(G)
        nx.draw(G, pos, with_labels=True, ax=plot, node_size=700, node_color="skyblue", font_size=8)

if __name__ == "__main__":
    root = tk.Tk()
    app = NetworkScannerApp(root)
    root.mainloop()
