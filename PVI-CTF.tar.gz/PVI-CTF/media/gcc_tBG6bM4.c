#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdlib.h>

void secret_function(int client_socket) {
    FILE *file = fopen("flag.txt", "r");
    if (file == NULL) {
        perror("error flag.txt");
        return;
    }

    char buffer[1024];
    size_t bytesRead;

    while ((bytesRead = fread(buffer, 1, sizeof(buffer), file)) > 0) {
        if (send(client_socket, buffer, bytesRead, 0) == -1) {
            perror("ERROR");
            break;
        }
    }

    fclose(file);
}

void vulnerable_function(int client_socket) {
    char buffer[64];
    ssize_t bytes_received = recv(client_socket, buffer, sizeof(buffer), 0);
    if (bytes_received <= 0) {
        perror("ERROR");
        return;
    }
    buffer[bytes_received] = '\0';
    printf("Получен текст: %s\n", buffer);
}

int main() {
    int server_socket;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_addr_len = sizeof(client_addr);

    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket == -1) {
        perror("Ошибка при создании сокета");
        return 1;
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(12345);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    if (bind(server_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1) {
        perror("ERROR");
        return 1;
    }

    if (listen(server_socket, 5) == -1) {
        perror("ERROR");
        return 1;
    }

    printf("Ожидание подключения...\n");

    while (1) {
        int client_socket = accept(server_socket, (struct sockaddr*)&client_addr, &client_addr_len);
        if (client_socket == -1) {
            perror("Ошибка при принятии подключения");
            continue;
        }

        printf("Подключение принято!\n");

       
        char buffer[64];
        ssize_t bytes_received = recv(client_socket, buffer, sizeof(buffer), 0);
        if (bytes_received != 64) {
            perror("ERROR");
            close(client_socket);
            continue;
        }

        
        secret_function(client_socket);

       
        close(client_socket);
    }

    
    return 0;
}
