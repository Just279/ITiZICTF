
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))




SECRET_KEY = 'hk-ez4*0s9$ufht5el_8(d)d(&xlm8swqudx&*duza&z*5tv@('

DEBUG =  False

ALLOWED_HOSTS = ['10.3.207.111' , 'pvivng-ctf' , '192.168.238.72' , '127.0.0.1' , '46.146.220.74']



MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'lakshya.middleware.RedirectMiddleware',
]

SESSION_ENGINE = "django.contrib.sessions.backends.db"
SESSION_COOKIE_AGE = 1209600 
SESSION_COOKIE_NAME = 'sessionid'
SESSION_COOKIE_SECURE = False       
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_SAMESITE = 'Strict'
SESSION_EXPIRE_AT_BROWSER_CLOSE = True

CSRF_TRUSTED_ORIGINS = ['https://46.146.220.74', 'http://46.146.220.74']

INSTALLED_APPS = [
    'django.contrib.sessions',
    'django.contrib.admin',
    'django.contrib.contenttypes',
    'django.contrib.auth',
    'ctf',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'sslserver',
]

ROOT_URLCONF = 'lakshya.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR, 'ctf', 'templates')],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'lakshya.wsgi.application'




DATABASES = {
        'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'pl',     
        'USER': 'postgres',         
        'PASSWORD': '654321',  
        'HOST': 'localhost',         
        'PORT': '5432',                   
    }
}




AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

APPEND_SLASH = True


LANGUAGE_CODE = "ru"

TIME_ZONE = 'Asia/Yekaterinburg'



USE_I18N = True

USE_TZ = True

STATIC_ROOT = os.path.join(BASE_DIR, '/static/')

STATIC_URL = '/static/'

MEDIA_URL = '/media/'
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')

#SECURE_SSL_REDIRECT = True

