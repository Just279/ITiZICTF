from django.contrib import admin
from .models import UserProfile, Questions, Submission


class QuestionsAdmin(admin.ModelAdmin):
    list_display = ('Qtitle', 'level', 'category', 'points', 'solved_by')
    list_filter = ('level', 'category')
    search_fields = ('Qtitle', 'category')

class SubmissionAdmin(admin.ModelAdmin):
    list_display = ('question', 'user', 'curr_score', 'solved', 'sub_time')
    list_filter = ('question__category', 'question__level')
    search_fields = ('question__Qtitle', 'user__user__username')

admin.site.register(UserProfile)
admin.site.register(Questions)
admin.site.register(Submission)
