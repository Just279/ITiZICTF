from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from . import views
from .views import user_profile
from .views import courses


urlpatterns = [
    path('', views.index, name='index'),
    path('404', views.error, name='error'),
    path('register', views.signup, name='signup'),
    path('about', views.about, name='about'),
    path('login', views.login1, name='login1'),
    path('instructions', views.inst, name='inst'),
    path('QUEST', views.Quest, name='Quest'),
    path('logout', views.logout, name='logout'),
    path('check', views.check, name='check'),
    path('hint', views.hint, name='hint'),
    path('leaderboard', views.leaderboard, name='leaderboard'),
    path('download/<int:Qid>/', views.download_file, name='download_file'),
    path('profile/', user_profile, name='user_profile'),
    path('courses/', courses, name='courses'),
]


if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
