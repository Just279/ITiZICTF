#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>

#define BUFFER_SIZE 2048

typedef struct {
    int client_socket;
    int account_balance;
} ClientData;

void sendData(int client_socket, const char *data_to_send) {
    send(client_socket, data_to_send, strlen(data_to_send), 0);
}

void sendFileContent(int client_socket, const char *filename) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        sendData(client_socket, "Флаг не найден: пожалуйста, запустите это на сервере\n");
        exit(0);
    }

    char buffer[BUFFER_SIZE];
    while (fgets(buffer, sizeof(buffer), file) != NULL) {
        sendData(client_socket, buffer);
    }

    fclose(file);
}

void *handleClient(void *arg) {
    ClientData *client_data = (ClientData *)arg;
    int client_socket = client_data->client_socket;
    int account_balance = client_data->account_balance;
    free(client_data);

    while (1) {
        sendData(client_socket, "Добро пожаловать в обмен флагами\nМы продаем флаги\n");
        sendData(client_socket, "\n1. Проверить баланс\n2. Купить флаги\n3. Выйти\n");

        char buffer[BUFFER_SIZE];
        recv(client_socket, buffer, sizeof(buffer), 0);
        int menu = atoi(buffer);

        if (menu == 1) {
            snprintf(buffer, sizeof(buffer), "\n\n\n Баланс: %d \n\n\n", account_balance);
            sendData(client_socket, buffer);
        } else if (menu == 2) {
            sendData(client_socket, "В наличии\n1. Пустой флаг\n2. Настоящий флаг\n");

            recv(client_socket, buffer, sizeof(buffer), 0);
            int auction_choice = atoi(buffer);

            if (auction_choice == 1) {
                sendData(client_socket, "Эти подделки стоят 900 каждый, введите желаемое количество\n");

                recv(client_socket, buffer, sizeof(buffer), 0);
                int number_flags = atoi(buffer);

                if (number_flags >= 0) {
                    int total_cost = 900 * number_flags;
                    if (total_cost > 0 && total_cost <= account_balance) {
                        sendData(client_socket, "\nПоздравляем с покупкой!\n");
                        account_balance -= total_cost;
                        sendData(client_socket, "Ваш текущий баланс после транзакции: ");
                        snprintf(buffer, sizeof(buffer), "%d\n\n", account_balance);
                        sendData(client_socket, buffer);
                    } else {
                        sendData(client_socket, "Недостаточно средств для совершения покупки\n");
                    }
                } else {
                    int total_gain = -900 * number_flags;
                    account_balance += total_gain;

                    snprintf(buffer, sizeof(buffer), "\nВы получаете %d за покупку!\n", total_gain);
                    sendData(client_socket, buffer);
                }
            } else if (auction_choice == 2) {
                sendData(client_socket, "Настоящие флаги стоят 100000 долларов, и у нас есть всего 1 в наличии\nВведите 1, чтобы купить один\n");

                recv(client_socket, buffer, sizeof(buffer), 0);
                int bid = atoi(buffer);

                if (bid == 1) {
                    if (account_balance > 100000) {
                        sendData(client_socket, "\nПоздравляем с покупкой!\n");
                        sendFileContent(client_socket, "realflag.txt");

                        account_balance -= 100000;
                        sendData(client_socket, "\nВаш текущий баланс после транзакции: ");
                        snprintf(buffer, sizeof(buffer), "%d\n\n", account_balance);
                        sendData(client_socket, buffer);
                    } else {
                        sendData(client_socket, "\nНедостаточно средств для транзакции\n\n\n");
                    }
                }
            }
        } else if (menu == 3) {
            break; // Пользователь выбрал "Выйти"
        }
    }

    close(client_socket);
    pthread_exit(NULL);
}

int main() {
    setbuf(stdout, NULL);

    int server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket == -1) {
        perror("Ошибка создания сокета");
        exit(EXIT_FAILURE);
    }

    struct sockaddr_in server_address;
    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = INADDR_ANY;
    server_address.sin_port = htons(12344);

    if (bind(server_socket, (struct sockaddr*)&server_address, sizeof(server_address)) == -1) {
        perror("Ошибка при привязке");
        close(server_socket);
        exit(EXIT_FAILURE);
    }

    if (listen(server_socket, 5) == -1) {
        perror("Ошибка при прослушивании");
        close(server_socket);
        exit(EXIT_FAILURE);
    }

    while (1) {
        printf("Ожидание соединения на порту 12344...\n");

        int client_socket = accept(server_socket, NULL, NULL);
        if (client_socket == -1) {
            perror("Ошибка при принятии соединения");
            continue;
        }

        pthread_t client_thread;
        ClientData *client_data = (ClientData *)malloc(sizeof(ClientData));
        client_data->client_socket = client_socket;
        client_data->account_balance = 1100;

        if (pthread_create(&client_thread, NULL, handleClient, (void *)client_data) != 0) {
            perror("Ошибка создания потока для клиента");
            close(client_socket);
            free(client_data);
        } else {
            pthread_detach(client_thread);
        }
    }

    close(server_socket);
    return 0;
}
