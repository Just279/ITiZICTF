#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <pthread.h>

#define BUFFER_SIZE 1024

void secret_function(int client_socket) {
    FILE *file = fopen("flag.txt", "r");
    if (file == NULL) {
        perror("error flag.txt");
        return;
    }

    char buffer[BUFFER_SIZE];
    size_t bytesRead;

    while ((bytesRead = fread(buffer, 1, sizeof(buffer), file)) > 0) {
        if (send(client_socket, buffer, bytesRead, 0) == -1) {
            perror("ERROR");
            break;
        }
    }

    fclose(file);
}

void vulnerable_function(int client_socket) {
    char buffer[BUFFER_SIZE];
    ssize_t bytes_received = recv(client_socket, buffer, sizeof(buffer), 0);
    if (bytes_received <= 0) {
        perror("ERROR");
        return;
    }
    buffer[bytes_received] = '\0';
    printf("Получен текст: %s\n", buffer);
}

void *handleClient(void *arg) {
    int client_socket = *((int *)arg);
    free(arg);

    char buffer[64];
    ssize_t bytes_received = recv(client_socket, buffer, sizeof(buffer), 0);
    if (bytes_received != 64) {
        perror("ERROR");
        close(client_socket);
        pthread_exit(NULL);
    }

    secret_function(client_socket);

    close(client_socket);
    pthread_exit(NULL);
}

int main() {
    int server_socket;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_addr_len = sizeof(client_addr);

    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket == -1) {
        perror("Ошибка при создании сокета");
        return 1;
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(12345);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    if (bind(server_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1) {
        perror("ERROR");
        return 1;
    }

    if (listen(server_socket, 5) == -1) {
        perror("ERROR");
        return 1;
    }

    printf("Ожидание подключения...\n");

    while (1) {
        int *client_socket = (int *)malloc(sizeof(int));
        *client_socket = accept(server_socket, (struct sockaddr*)&client_addr, &client_addr_len);
        if (*client_socket == -1) {
            perror("Ошибка при принятии подключения");
            free(client_socket);
            continue;
        }

        printf("Подключение принято!\n");

        pthread_t client_thread;
        int *client_socket_copy = (int *)malloc(sizeof(int));
        *client_socket_copy = *client_socket;

        if (pthread_create(&client_thread, NULL, handleClient, (void *)client_socket_copy) != 0) {
            perror("Ошибка создания потока для клиента");
            close(*client_socket);
            free(client_socket_copy);
        } else {
            pthread_detach(client_thread);
        }
    }

    close(server_socket);
    return 0;
}
