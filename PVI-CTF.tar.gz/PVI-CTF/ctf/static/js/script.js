function showCategory(category) {
    document.getElementById('popupTitle').innerText = category;

    const categoryDescriptions = {
        'Web': 'В данной категории задачи, связанные с веб-разработкой и безопасностью веб-приложений. Это включает в себя решение задач по созданию и оптимизации веб-сайтов, а также аспекты, связанные с обеспечением безопасности веб-приложений.',
        'Reversing': 'В этой категории вы столкнетесь с задачами, где требуется разгадать обратное проектирование программ и файлов. Это включает в себя анализ исполняемого кода, понимание работы программы в обратном порядке и исследование структуры файлов.',
        'Стеганография': 'Задачи в этой категории связаны с изучением и обнаружением скрытых данных в различных медиафайлах, таких как изображения, звуки и другие. Вам предстоит использовать методы стенографии для извлечения или скрытия информации.',
        'Pwn': 'В этой категории вам предстоит атаковать и эксплуатировать уязвимости в программном обеспечении. Задачи могут включать в себя обход системной безопасности, выполнение вредоносного кода и получение несанкционированного доступа.',
        'Криптография': 'В этой категории вам предстоит решать задачи, связанные с шифрованием и дешифрованием данных. Это может включать в себя анализ криптографических алгоритмов, создание криптографических решений и разгадывание шифров.',
        'Другие': 'Здесь находятся различные задачи, которые требуют знаний сразу нескольких категорий. Это может включать в себя мультидисциплинарные задачи, где необходимо применять навыки из различных областей информационной безопасности.'
    };

    document.getElementById('popupDescription').innerText = categoryDescriptions[category];

    document.getElementById('overlay1').style.display = 'block';
    document.getElementById('popup1').style.display = 'block';
    setTimeout(() => {
        document.getElementById('overlay1').style.opacity = '1';
        document.getElementById('popup1').style.opacity = '1';
        document.getElementById('popup1').style.transform = 'translate(-50%, -50%) scale(1)';
    }, 10);
}

function hideOverlay() {
    document.getElementById('overlay1').style.opacity = '0';
    document.getElementById('popup1').style.opacity = '0';
    document.getElementById('popup1').style.transform = 'translate(-50%, -50%) scale(0)';

    setTimeout(() => {
        document.getElementById('overlay1').style.display = 'none';
        document.getElementById('popup1').style.display = 'none';
    }, 300);
}




function smoothScroll(hash) {
    $('html, body').animate({
        scrollTop: $(hash).offset().top
    }, 800);
}


$('.navega_sunka a').on('click', function (event) {
    if (this.hash !== "") {
        event.preventDefault();
        var hash = this.hash;
        smoothScroll(hash);
    }
});


document.addEventListener('DOMContentLoaded', function() {
    document.cookie = "last_visited_page=" + window.location.href;
});


document.addEventListener('DOMContentLoaded', function() {
    sessionStorage.setItem("last_visited_page", window.location.href);
});

document.getElementById("goBackButton").onclick = function() {
    window.history.back();
};

