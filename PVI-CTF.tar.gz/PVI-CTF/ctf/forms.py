from django import forms
from django.contrib.auth.models import User
from .models import UserProfile
import re

class UserProfileForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['email', 'avatar', 'team_name', 'last_name', 'first_name', 'middle_name', 'phone_number']
        labels = {
            'email': 'Электронная почта',
            'avatar': 'Аватар',
            'team_name': 'Название команды',
            'last_name': 'Фамилия',
            'first_name': 'Имя',
            'middle_name': 'Отчество',
            'phone_number': 'Номер телефона',
        }


    def clean_first_name(self):
        first_name = self.cleaned_data.get('first_name')
        if first_name and not all(char.isalpha() or char.isspace() and char.isascii() for char in first_name):
            raise forms.ValidationError('Имя должно содержать только русские буквы.')
        return first_name

    def clean_last_name(self):
        last_name = self.cleaned_data.get('last_name')
        if last_name and not all(char.isalpha() or char.isspace() and char.isascii() for char in last_name):
            raise forms.ValidationError('Фамилия должна содержать только русские буквы.')
        return last_name

    def clean_middle_name(self):
        middle_name = self.cleaned_data.get('middle_name')
        if middle_name and not all(char.isalpha() or char.isspace() and char.isascii() for char in middle_name):
            raise forms.ValidationError('Отчество должно содержать только русские буквы.')
        return middle_name

    def clean_email(self):
        email = self.cleaned_data.get('email')
        if email and not re.match(r"[^@]+@[^@]+\.[^@]+", email):
            raise forms.ValidationError('Пожалуйста, введите корректный адрес электронной почты.')
        return email

    def clean_phone_number(self):
        phone_number = self.cleaned_data.get('phone_number')
        if phone_number and (not phone_number.isdigit() or len(phone_number) > 11):
            raise forms.ValidationError('Номер телефона может содержать только цифры и не должен превышать 11 символов.')
        return phone_number

    def __init__(self, *args, **kwargs):
        super(UserProfileForm, self).__init__(*args, **kwargs)
   
