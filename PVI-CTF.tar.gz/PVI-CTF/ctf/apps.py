from django.apps import AppConfig


class CtfConfig(AppConfig):
    name = 'ctf'
