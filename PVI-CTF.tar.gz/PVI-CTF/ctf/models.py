from django.db import models
from django.contrib.auth.models import User


EASY = 'E'
MEDIUM = 'M'
HARD = 'H'
WEB = 'category_web'
REVERSE = 'category_reversing'
STEG = 'category_steg'
PWNING = 'category_pwning'
MISC = 'category_misc'
CRYPT = 'category_crypt'


difficulty = [(EASY, 'easy'), (MEDIUM, 'medium'), (HARD, 'hard')]
category = [(WEB, 'category_web'), (REVERSE, 'category_reversing'), (STEG, 'category_steg'), (PWNING, 'category_pwning'), (MISC, 'category_misc'), (CRYPT, 'category_crypt')]


class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    Rid = models.CharField(max_length=100, default="EINC-5e5a")
    score = models.IntegerField(default=0)
    totlesub = models.IntegerField(default=0)
    latest_sub_time = models.CharField(default="00:00", max_length=10)
    time = models.TimeField(default="00:00")
    email = models.EmailField(blank=True)
    avatar = models.ImageField(upload_to='avatars/', blank=True)
    team_name = models.CharField(max_length=100, blank=True)
    last_name = models.CharField(max_length=30, blank=True)
    first_name = models.CharField(max_length=30, blank=True)
    middle_name = models.CharField(max_length=30, blank=True)
    phone_number = models.CharField(max_length=15, blank=True)
    is_logged_in = models.BooleanField(default=False)
    
    
    class Meta:
    	app_label = 'ctf'
        

    def __str__(self):
        return f'{self.user.username} ({self.team_name})'


class Questions(models.Model):
    Qid = models.IntegerField(default='0')
    Qtitle = models.CharField(max_length=70)
    Qdes = models.CharField(max_length=1000)
    Hint = models.CharField(max_length=500, default="hint is ----")
    level = models.CharField(max_length=2, choices=difficulty, default=HARD)
    Easy = models.IntegerField(default=1)
    Med = models.IntegerField(default=1)
    Hard = models.IntegerField(default=1)
    flag = models.CharField(max_length=100, default='CTF{}')
    points = models.IntegerField(default=0)
    solved_by = models.IntegerField(default=0)
    file = models.FileField(blank=True)
    category = models.CharField(max_length=50, choices=category, default=STEG)


class Submission(models.Model):
    question = models.ForeignKey(Questions, on_delete=models.CASCADE)
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE)
    curr_score = models.IntegerField(default=0)
    solved = models.IntegerField(default=0)
    sub_time = models.CharField(default="00:00", max_length=10)
    completed_tasks = models.ManyToManyField(Questions, related_name='completed_by', blank=True)


class Meta:
        unique_together = ('question', 'user')