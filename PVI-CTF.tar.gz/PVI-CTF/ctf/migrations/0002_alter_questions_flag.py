

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('ctf', '0001_initial'),
    ]

    operations = [
        migrations.AlterField(
            model_name='questions',
            name='flag',
            field=models.CharField(default='CTF{}', max_length=100),
        ),
    ]
