window.addEventListener('DOMContentLoaded', function() {
    var backToTopButton = document.getElementById('back-to-top-btn');

    window.addEventListener('scroll', function() {
        if (window.pageYOffset > 100) {  to appear
            backToTopButton.style.display = 'block';
        } else {
            backToTopButton.style.display = 'none';
        }
    });

    window.addEventListener('resize', function() {
        backToTopButton.style.left = '20px'; 
    });

    // Initial position setup
    window.dispatchEvent(new Event('resize'));
});
