

from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='Questions',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('Qid', models.IntegerField(default='0')),
                ('Qtitle', models.CharField(max_length=70)),
                ('Qdes', models.CharField(max_length=1000)),
                ('Hint', models.CharField(default='hint is ----', max_length=500)),
                ('level', models.CharField(choices=[('E', 'easy'), ('M', 'medium'), ('H', 'hard')], default='H', max_length=2)),
                ('Easy', models.IntegerField(default=1)),
                ('Med', models.IntegerField(default=1)),
                ('Hard', models.IntegerField(default=1)),
                ('flag', models.CharField(default='pict_CTF{}', max_length=100)),
                ('points', models.IntegerField(default=0)),
                ('solved_by', models.IntegerField(default=0)),
                ('file', models.FileField(blank=True, upload_to='')),
                ('category', models.CharField(choices=[('category_web', 'category_web'), ('category_reversing', 'category_reversing'), ('category_steg', 'category_steg'), ('category_pwning', 'category_pwning'), ('category_misc', 'category_misc'), ('category_crypt', 'category_crypt')], default='category_steg', max_length=50)),
            ],
        ),
        migrations.CreateModel(
            name='UserProfile',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('Rid', models.CharField(default='EINC-5e5a', max_length=100)),
                ('score', models.IntegerField(default=0)),
                ('totlesub', models.IntegerField(default=0)),
                ('latest_sub_time', models.CharField(default='00:00', max_length=10)),
                ('time', models.TimeField(default='00:00')),
                ('user', models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.CreateModel(
            name='Submission',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('curr_score', models.IntegerField(default=0)),
                ('solved', models.IntegerField(default=0)),
                ('sub_time', models.CharField(default='00:00', max_length=10)),
                ('question', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='ctf.Questions')),
                ('user', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='ctf.UserProfile')),
            ],
        ),
    ]
